package org.example.controllers;

import org.example.dao.ProductMemoryDB;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/product/delete")
public class ProductDeleteServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        // get the product id from the request parameter
        Long id = Long.parseLong(req.getParameter("id"));
        // delete the product from the database
        ProductMemoryDB.delete(id);
        // redirect to the product list page
        resp.sendRedirect(req.getContextPath()+"/products");
    }
}