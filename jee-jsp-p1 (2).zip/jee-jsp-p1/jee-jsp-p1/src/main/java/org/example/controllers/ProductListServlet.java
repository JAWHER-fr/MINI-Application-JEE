package org.example.controllers;

import org.example.dao.ProductMemoryDB;
import org.example.models.Product;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/products")
public class ProductListServlet extends HttpServlet {


    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        // retrieve all products from the database
        List<Product> products = ProductMemoryDB.findAll();
        // set the products as a request attribute and forward to the JSP page
        req.setAttribute("products", products);
        // forward to the JSP page to display the products
        RequestDispatcher dispatcher = req.getRequestDispatcher("./products.jsp");
        dispatcher.forward(req, resp);
    }
}