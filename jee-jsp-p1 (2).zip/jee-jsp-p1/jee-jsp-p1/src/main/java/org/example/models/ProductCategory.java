package org.example.models;

public enum ProductCategory {
    ELECTRONICS,
    CLOTHING,
    HOME,
    BEAUTY,
    SPORTS,
    TOYS,
    BOOKS,
    FOOD,
    AUTOMOTIVE,
    OTHER
}
