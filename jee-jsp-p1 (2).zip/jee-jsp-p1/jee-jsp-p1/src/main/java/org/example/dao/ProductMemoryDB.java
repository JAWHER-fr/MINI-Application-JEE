package org.example.dao;

import org.example.models.Product;

import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

public class ProductMemoryDB {

    private static List<Product> products = new ArrayList<>();
    private static AtomicLong counter = new AtomicLong(1);

    public static void add(Product p) {
        p.setId(counter.getAndIncrement());
        products.add(p);
    }

    public static List<Product> findAll() {
        return products;
    }

    public static void delete(Long id) {
        products.removeIf(p -> p.getId().equals(id));
    }
}