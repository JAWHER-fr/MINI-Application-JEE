package org.example.controllers;

import org.example.dao.ProductMemoryDB;
import org.example.models.Product;
import org.example.models.ProductCategory;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/product/create")
public class ProductCreateServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        Product p = new Product();
        String name = req.getParameter("name");
        p.setName(name);
        p.setDescription(req.getParameter("description"));
        p.setPrice(Double.parseDouble(req.getParameter("price")));
        p.setQuantity(Integer.parseInt(req.getParameter("quantity")));
        p.setCategory(ProductCategory.valueOf(req.getParameter("category")));
        // save the product in the database
        ProductMemoryDB.add(p);
        // redirect to the product list page
        resp.sendRedirect(req.getContextPath()+"/products");
    }
}