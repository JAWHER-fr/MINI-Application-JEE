package org.example.models;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class Product implements Serializable {
    private Long id;
    private ProductCategory category;
    private String name;
    private String description;
    private double price;
    private int quantity;
}
