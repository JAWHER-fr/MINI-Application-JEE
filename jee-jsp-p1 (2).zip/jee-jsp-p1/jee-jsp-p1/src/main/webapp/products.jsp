<%@ page language="java" contentType="text/html;charset=UTF-8" %>
<%@ page import="java.util.List" %>
<%@ page import="org.example.models.Product" %>

<!DOCTYPE html>
<html>
<head>
    <title>Products</title>

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f6f9;
        }

        /* HEADER */
        header {
            background: #343a40;
            color: white;
            padding: 20px;
            text-align: center;
        }

        /* NAV */
        nav {
            background: #007bff;
            display: flex;
            justify-content: center;
        }

        nav a {
            color: white;
            padding: 15px 20px;
            text-decoration: none;
            font-weight: bold;
        }

        nav a:hover {
            background: #0056b3;
        }

        /* CONTAINER */
        .container {
            width: 90%;
            margin: 30px auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            color: #333;
        }

        /* BUTTON */
        .btn-add {
            display: inline-block;
            margin-bottom: 15px;
            padding: 10px 15px;
            background: #28a745;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
        }

        .btn-add:hover {
            background: #218838;
        }

        /* TABLE */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        th {
            background: #007bff;
            color: white;
            padding: 10px;
        }

        td {
            padding: 10px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }

        tr:hover {
            background: #f1f1f1;
        }

        /* DELETE */
        .delete {
            color: white;
            background: red;
            padding: 6px 10px;
            text-decoration: none;
            border-radius: 5px;
        }

        .delete:hover {
            background: darkred;
        }

        /* FOOTER */
        footer {
            background: #343a40;
            color: white;
            text-align: center;
            padding: 15px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }

    </style>
</head>

<body>

<!-- HEADER -->
<header>
    <h1>Product Management System</h1>
</header>

<!-- NAV -->
<nav>
    <a href="./index.html">Home</a>
    <a href="./createProduct.html">Add Product</a>
    <a href="./products">Products List</a>
</nav>

<!-- CONTENT -->
<div class="container">

    <h2>Product List</h2>

    <a class="btn-add" href="./createProduct.html">➕ Create New Product</a>

    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Description</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Category</th>
            <th>Action</th>
        </tr>

        <%
            List<Product> products = (List<Product>) request.getAttribute("products");
            for(Product p : products) {
        %>

        <tr>
            <td><%= p.getId() %></td>
            <td><%= p.getName() %></td>
            <td><%= p.getDescription() %></td>
            <td><%= p.getPrice() %></td>
            <td><%= p.getQuantity() %></td>
            <td><%= p.getCategory() %></td>
            <td>
                <a class="delete" href="./product/delete?id=<%= p.getId() %>">Delete</a>
            </td>
        </tr>

        <% } %>

    </table>

</div>

<footer>
    © 2026 Java EE Project | JAWHER DRIDI
</footer>
</body>
</html>